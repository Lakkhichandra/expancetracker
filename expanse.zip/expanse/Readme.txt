How to run the Daily Expense Tracking System  Project
1. Download the  zip file
2. Extract the file and copy expance_tracker folder

************Credential for user panel  OR you can register your self ************************
Username: lakkhichandra3072001@gmail.com
Password:Lucky@12345

